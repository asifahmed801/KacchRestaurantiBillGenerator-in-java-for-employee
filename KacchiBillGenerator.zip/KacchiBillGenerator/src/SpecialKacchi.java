public class SpecialKacchi extends Kacchi{
    public SpecialKacchi(Boolean half){
        super(half);
        super.addKabab();
        super.addRost();
    }

    @Override
    public void addRost() {
    }

    @Override
    public void addKabab() {

    }
}
