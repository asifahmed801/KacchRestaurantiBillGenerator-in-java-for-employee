public class Main {

    public static void main(String[] args) {

        System.out.println("_______________________________________________________________________");
        System.out.println("\nFor Normal Kacchi Get Bill From Here : \n\n");

        Kacchi KacchiVai = new Kacchi(false);
          KacchiVai.addKabab();
          KacchiVai.addRost();
          KacchiVai.takeAway();
          KacchiVai.getBill();

          System.out.println("_______________________________________________________________________");
          System.out.println("\nFor Special Kacchi Get Bill From Here : \n\n");

        SpecialKacchi SKacchi = new SpecialKacchi(false);
        SKacchi.getBill();
    }
}