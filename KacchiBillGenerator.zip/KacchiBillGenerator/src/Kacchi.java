
public class Kacchi {
    private int price ;
    private Boolean half ;
    private int RostPricing = 120 ;
    private int KababPricing = 100 ;
    private int BagPricing = 30 ;
    private int halfKacchiPrice;
    private boolean isRostAdded = false ;
    private boolean isKababAdded = false;
    private boolean isTaken = false;

    public Kacchi(Boolean half) {
        this.half = half;
       if(this.half){
           this.price = 280;
    }
       else {
           this.price= 420;
       }
        halfKacchiPrice = this.price;
   }


//    public void getKacchi(){
//        System.out.println(this.price);
//    }

    public void addRost(){
        isRostAdded = true;
        System.out.println("Rost added");
        this.price += RostPricing ;
    }
    public void addKabab(){
        isKababAdded = true;
        System.out.println("Kabab added");
        this.price += KababPricing ;
    }
    public void takeAway(){
        isTaken = true;
        System.out.println("Packeging");
        this.price += BagPricing ;
    }
    public void getBill(){
        String Bill = "";
        System.out.println("Kacchi : "+ halfKacchiPrice);
        if(isRostAdded){
            Bill += "Extra Rost added :" + RostPricing + "\n";
        }
        if(isKababAdded){
            Bill += "Extra Kabab added :" + KababPricing + "\n";
        }
        if(isTaken){
            Bill += "Extra Bag added :" + BagPricing  + "\n";
        }
    Bill += "\n\nTotal Bill : " + this.price + "\n";
        System.out.println(Bill);
    }




}
